<template>
    <div class="col-md-3">
        <div class="card placeholder-glow">
            <div class="ratio ratio-21x9 card-img-top placeholder"></div>
            <div class="card-body">
                <div class="placeholder col-9 mb-3"></div>
                <div class="placeholder placeholder-xs col-10"></div>
                <div class="placeholder placeholder-xs col-11"></div>
            </div>
            <div class="card-footer">
                <div class="d-flex justify-content-between">
                    <a href="#" tabindex="-1" class="btn btn-primary disabled placeholder col-4" aria-hidden="true"></a>
                    <a href="#" tabindex="-1" class="btn disabled placeholder col-4" aria-hidden="true"></a>
                </div>
            </div>
        </div>
    </div>
</template>
