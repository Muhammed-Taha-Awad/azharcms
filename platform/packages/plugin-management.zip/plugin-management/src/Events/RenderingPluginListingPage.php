<?php

namespace Botble\PluginManagement\Events;

use Botble\Base\Events\Event;
use Illuminate\Foundation\Events\Dispatchable;

class RenderingPluginListingPage extends Event
{
    use Dispatchable;
}
