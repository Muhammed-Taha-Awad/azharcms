<?php

return [
    'enable_plugin_manager' => env('CMS_PLUGIN_ENABLE_PLUGIN_MANAGER', true),
    'hide_plugin_author' => env('CMS_PLUGIN_HIDE_AUTHOR', false),
    'enable_plugin_list_cache' => env('CMS_PLUGIN_ENABLE_PLUGIN_LIST_CACHE', false),
    'enable_marketplace_feature' => env('CMS_ENABLE_MARKETPLACE_FEATURE', true),
];
