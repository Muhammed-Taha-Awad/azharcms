# Changelog

All notable changes to `fob-comment` will be documented in this file

## 1.0.0 - 2024-03-12

- First release 🥳
